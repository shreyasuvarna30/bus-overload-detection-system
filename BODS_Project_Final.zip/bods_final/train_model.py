"""
Bus Overload Detection System
Script 2: Model Training & Evaluation
"""

import pandas as pd
import numpy as np
import json
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import (classification_report, confusion_matrix,
                              roc_auc_score, accuracy_score, f1_score)
import warnings
warnings.filterwarnings('ignore')

print("=" * 60)
print("   BUS OVERLOAD DETECTION — MODEL TRAINING")
print("=" * 60)

# Load data
df = pd.read_csv('/home/claude/bus_overload_detection/bus_data.csv')
print(f"\n📦 Loaded {len(df)} records")

# Feature engineering
df['hour_sin'] = np.sin(2 * np.pi * df['hour'] / 24)
df['hour_cos'] = np.cos(2 * np.pi * df['hour'] / 24)
df['occupancy_lag'] = df.groupby('route_id')['occupancy_rate'].shift(1).fillna(0)
df['route_encoded'] = LabelEncoder().fit_transform(df['route_id'])

FEATURES = ['hour', 'hour_sin', 'hour_cos', 'is_weekend', 'is_peak_hour',
            'bus_capacity', 'route_encoded', 'temperature_celsius',
            'rainfall_mm', 'occupancy_lag']

TARGET = 'is_overloaded'

X = df[FEATURES]
y = df[TARGET]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

print(f"   Train size: {len(X_train)}, Test size: {len(X_test)}")
print(f"   Overload rate in train: {y_train.mean()*100:.1f}%")

# Train multiple models
models = {
    'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=10, random_state=42),
    'Gradient Boosting': GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, random_state=42),
    'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
}

results = {}
print("\n🔬 Training Models...\n")

for name, model in models.items():
    if name == 'Logistic Regression':
        model.fit(X_train_scaled, y_train)
        y_pred = model.predict(X_test_scaled)
        y_prob = model.predict_proba(X_test_scaled)[:, 1]
    else:
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        y_prob = model.predict_proba(X_test)[:, 1]
    
    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_prob)
    cm = confusion_matrix(y_test, y_pred).tolist()
    
    results[name] = {
        'accuracy': round(acc, 4),
        'f1_score': round(f1, 4),
        'roc_auc': round(auc, 4),
        'confusion_matrix': cm
    }
    print(f"  {name}:")
    print(f"    Accuracy: {acc*100:.2f}%  |  F1: {f1:.4f}  |  AUC-ROC: {auc:.4f}")

# Best model details (Random Forest)
best_model = models['Random Forest']
importances = dict(zip(FEATURES, best_model.feature_importances_.tolist()))
results['feature_importances'] = importances

# Route-level analysis
route_stats = df.groupby('route_id').agg(
    total_trips=('is_overloaded', 'count'),
    overload_trips=('is_overloaded', 'sum'),
    avg_occupancy=('occupancy_rate', 'mean'),
    max_occupancy=('occupancy_rate', 'max'),
    avg_passengers=('passenger_count', 'mean'),
    bus_capacity=('bus_capacity', 'first')
).reset_index()
route_stats['overload_pct'] = (route_stats['overload_trips'] / route_stats['total_trips'] * 100).round(2)
route_stats['avg_occupancy'] = route_stats['avg_occupancy'].round(4)
route_stats['max_occupancy'] = route_stats['max_occupancy'].round(4)

# Hourly analysis
hourly = df.groupby('hour').agg(
    overload_rate=('is_overloaded', 'mean'),
    avg_occupancy=('occupancy_rate', 'mean'),
    total_trips=('is_overloaded', 'count')
).reset_index()
hourly['overload_rate'] = (hourly['overload_rate'] * 100).round(2)
hourly['avg_occupancy'] = (hourly['avg_occupancy'] * 100).round(2)

# Save all results
output = {
    'model_results': results,
    'route_stats': route_stats.to_dict(orient='records'),
    'hourly_stats': hourly.to_dict(orient='records'),
    'summary': {
        'total_records': len(df),
        'overload_rate': round(df['is_overloaded'].mean() * 100, 2),
        'routes': df['route_id'].nunique(),
        'date_range': f"{df['date'].min()} to {df['date'].max()}"
    }
}

with open('/home/claude/bus_overload_detection/results.json', 'w') as f:
    json.dump(output, f, indent=2)

print("\n✅ Results saved to results.json")
print("\n📊 Route Summary:")
print(route_stats[['route_id', 'bus_capacity', 'overload_pct', 'avg_occupancy']].to_string(index=False))
