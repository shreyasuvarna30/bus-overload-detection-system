"""
Bus Overload Detection System
Script 1: Synthetic Dataset Generator
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)

ROUTES = {
    'Route_101': {'capacity': 50, 'peak_factor': 1.4},
    'Route_202': {'capacity': 40, 'peak_factor': 1.5},
    'Route_303': {'capacity': 60, 'peak_factor': 1.2},
    'Route_404': {'capacity': 45, 'peak_factor': 1.6},
    'Route_505': {'capacity': 55, 'peak_factor': 1.3},
}

STOPS = ['Central Station', 'Market Square', 'University', 'Hospital',
         'Shopping Mall', 'Industrial Zone', 'Airport', 'Railway Junction',
         'Sports Complex', 'City Park']

def is_peak_hour(hour):
    return (7 <= hour <= 9) or (17 <= hour <= 20)

def generate_passenger_count(capacity, peak_factor, hour, is_weekend):
    base_load = 0.3
    if is_peak_hour(hour) and not is_weekend:
        load_factor = np.random.normal(peak_factor, 0.15)
    elif is_weekend and 10 <= hour <= 18:
        load_factor = np.random.normal(0.85, 0.15)
    elif 22 <= hour or hour <= 5:
        load_factor = np.random.normal(0.15, 0.05)
    else:
        load_factor = np.random.normal(0.6, 0.15)
    
    load_factor = max(0.05, load_factor)
    count = int(capacity * load_factor)
    count = max(0, min(count, int(capacity * 2.0)))
    return count

records = []
start_date = datetime(2024, 1, 1)

for day_offset in range(180):
    current_date = start_date + timedelta(days=day_offset)
    is_weekend = current_date.weekday() >= 5
    
    for route_id, route_info in ROUTES.items():
        capacity = route_info['capacity']
        peak_factor = route_info['peak_factor']
        
        num_trips = 18 if not is_weekend else 12
        trip_hours = sorted(random.sample(range(5, 23), min(num_trips, 18)))
        
        for hour in trip_hours:
            minute = random.randint(0, 59)
            timestamp = current_date.replace(hour=hour, minute=minute)
            
            passenger_count = generate_passenger_count(capacity, peak_factor, hour, is_weekend)
            occupancy_rate = passenger_count / capacity
            
            is_overloaded = 1 if passenger_count > capacity else 0
            overload_severity = max(0, (passenger_count - capacity) / capacity)
            
            records.append({
                'timestamp': timestamp,
                'date': current_date.date(),
                'hour': hour,
                'day_of_week': current_date.strftime('%A'),
                'is_weekend': int(is_weekend),
                'route_id': route_id,
                'bus_capacity': capacity,
                'passenger_count': passenger_count,
                'occupancy_rate': round(occupancy_rate, 4),
                'is_peak_hour': int(is_peak_hour(hour)),
                'stop_name': random.choice(STOPS),
                'is_overloaded': is_overloaded,
                'overload_severity': round(overload_severity, 4),
                'temperature_celsius': round(np.random.normal(22, 8), 1),
                'rainfall_mm': max(0, round(np.random.normal(0, 3), 1)),
            })

df = pd.DataFrame(records)
df = df.sort_values('timestamp').reset_index(drop=True)
df.to_csv('/home/claude/bus_overload_detection/bus_data.csv', index=False)

print(f"✅ Dataset generated: {len(df)} records")
print(f"   Date range: {df['date'].min()} to {df['date'].max()}")
print(f"   Overload rate: {df['is_overloaded'].mean()*100:.1f}%")
print(f"   Routes: {df['route_id'].nunique()}")
