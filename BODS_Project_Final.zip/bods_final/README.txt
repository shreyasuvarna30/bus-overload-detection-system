BUS OVERLOAD DETECTION SYSTEM (BODS)
=====================================

HOW TO RUN:
-----------
1. Double-click  bus_overload_system.html  in your file explorer
2. It opens in Chrome/Edge as a full working dashboard
3. Click START button — system comes alive!

TABS:
-----
Tab 1 — Live Dashboard
  • 8 buses monitored in real time (every 1.5 seconds)
  • 3 bus types: KSRTC, Express, Local
  • Route bars turn RED when overloaded
  • Dwell timer shows how long bus stops at each station
  • Passengers only change when bus leaves a stop (no flickering!)

Tab 2 — Bus Tracker Map
  • All 8 buses moving on Bengaluru city map
  • Distance shown in METERS from each bus to YOUR stop
  • ETA shown in minutes above each bus
  • STOP badge appears when bus is dwelling at a station
  • Click any bus for full route + stop-by-stop distance breakdown
  • Change your stop from the dropdown — all ETAs update instantly

Tab 3 — Project Report
  • Threshold explanation (NORMAL/WARNING/OVERLOAD)
  • Model comparison table (RF vs GB vs LR)
  • Confusion matrix
  • Feature importance bars
  • Key findings

THRESHOLD:
----------
  NORMAL   = below 82% capacity (green)
  WARNING  = 82% to 100% (amber)  ← early alert
  OVERLOAD = above 100% (red)     ← immediate alert

MODEL:
------
  Random Forest — 97.76% accuracy, AUC-ROC 0.9921

FILES:
------
  bus_overload_system.html — Main application (open this!)
  generate_data.py         — Creates the dataset
  train_model.py           — Trains ML models
  bus_data.csv             — Generated dataset (14,700 rows)

PYTHON SETUP (optional):
------------------------
  pip install pandas numpy scikit-learn
  python generate_data.py
  python train_model.py
